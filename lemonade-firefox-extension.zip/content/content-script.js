/**
 * Lemonade Pass Manager - Content Script (Firefox)
 * Detects login forms and injects the floating lemon button
 */

// Domains where Lemonade should NOT inject (the app itself)
const EXCLUDED_DOMAINS = [
    'lemonadepass.app',
    'app.lemonadepass.app',
    'localhost',
    '127.0.0.1'
];

/**
 * Check if current site should be excluded from autofill
 */
function isExcludedDomain() {
    const hostname = window.location.hostname;
    return EXCLUDED_DOMAINS.some(domain =>
        hostname === domain || hostname.endsWith('.' + domain)
    );
}

// Cache for credentials check - avoid repeated API calls
let credentialsCache = null;
let credentialsCacheExpiry = 0;
const CACHE_DURATION = 30000; // 30 seconds

// Skip injection on Lemonade's own domains
if (isExcludedDomain()) {
    // Skip injection on Lemonade app domain
} else if (window.lemonadeInjected) {
    // Already injected, skipping
} else {
    window.lemonadeInjected = true;
    initLemonade();
}

function initLemonade() {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => scanForLoginForms());
    } else {
        scanForLoginForms();
    }

    // Watch for dynamic forms (SPAs)
    observeDOMChanges();
}

/**
 * Check if credentials exist for the current domain
 * Returns cached result if available
 */
async function hasCredentialsForCurrentDomain() {
    const now = Date.now();

    // Return cached result if still valid
    if (credentialsCache !== null && now < credentialsCacheExpiry) {
        return credentialsCache;
    }

    try {
        const domain = window.location.hostname;
        const response = await browser.runtime.sendMessage({
            type: 'GET_CREDENTIALS',
            domain: domain
        });

        const hasCredentials = response && response.success && response.credentials && response.credentials.length > 0;

        // Cache the result
        credentialsCache = hasCredentials;
        credentialsCacheExpiry = now + CACHE_DURATION;

        return hasCredentials;
    } catch (error) {
        return false;
    }
}

/**
 * Scan the page for login forms
 * Only inject lemon button if credentials exist for this domain
 */
async function scanForLoginForms() {
    const passwordFields = findPasswordFields();

    if (passwordFields.length > 0) {
        // IMPORTANT: Only show lemon if user has saved credentials for this site
        const hasCredentials = await hasCredentialsForCurrentDomain();

        if (!hasCredentials) {
            return;
        }

        passwordFields.forEach(field => {
            if (!field.dataset.lemonadeProcessed) {
                field.dataset.lemonadeProcessed = 'true';
                injectLemonButton(field);
            }
        });
    }
}

/**
 * Find password input fields using multiple strategies
 */
function findPasswordFields() {
    const fields = [];

    // Strategy 1: Direct password inputs
    document.querySelectorAll('input[type="password"]').forEach(input => {
        if (isVisible(input)) {
            fields.push(input);
        }
    });

    // Strategy 2: Inputs with password-related attributes (for hidden type fields)
    const passwordKeywords = ['password', 'passwd', 'pwd', 'pass', 'contraseña'];
    document.querySelectorAll('input[type="text"], input:not([type])').forEach(input => {
        const name = (input.name || '').toLowerCase();
        const id = (input.id || '').toLowerCase();
        const autocomplete = (input.autocomplete || '').toLowerCase();

        if (passwordKeywords.some(kw => name.includes(kw) || id.includes(kw)) ||
            autocomplete === 'current-password' || autocomplete === 'new-password') {
            if (isVisible(input) && !fields.includes(input)) {
                fields.push(input);
            }
        }
    });

    return fields;
}

/**
 * Find the username field associated with a password field
 */
function findUsernameField(passwordField) {
    const form = passwordField.closest('form');
    const container = form || passwordField.parentElement?.parentElement || document.body;

    // Look for common username field patterns
    const usernameSelectors = [
        'input[type="email"]',
        'input[type="text"][autocomplete="username"]',
        'input[type="text"][autocomplete="email"]',
        'input[name*="user"]',
        'input[name*="email"]',
        'input[name*="login"]',
        'input[id*="user"]',
        'input[id*="email"]',
        'input[id*="login"]',
        'input[type="text"]'
    ];

    for (const selector of usernameSelectors) {
        const field = container.querySelector(selector);
        if (field && field !== passwordField && isVisible(field)) {
            return field;
        }
    }

    return null;
}

/**
 * Check if an element is visible
 */
function isVisible(element) {
    if (!element) return false;

    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();

    return style.display !== 'none' &&
           style.visibility !== 'hidden' &&
           style.opacity !== '0' &&
           rect.width > 0 &&
           rect.height > 0;
}

/**
 * Inject the floating lemon button near a password field
 */
function injectLemonButton(passwordField) {
    // Create shadow host for isolation
    const shadowHost = document.createElement('div');
    shadowHost.className = 'lemonade-shadow-host';
    shadowHost.style.cssText = 'position: absolute; z-index: 2147483647; pointer-events: none;';

    const shadow = shadowHost.attachShadow({ mode: 'closed' });

    // Create the lemon button with animated GIF
    const button = document.createElement('button');
    button.className = 'lemonade-btn';
    button.title = 'Autofill with Lemonade';

    // Use animated GIF instead of SVG
    const lemonImg = document.createElement('img');
    lemonImg.src = browser.runtime.getURL('icons/lemon-animated.gif');
    lemonImg.alt = 'Lemonade';
    lemonImg.className = 'lemonade-img';
    button.appendChild(lemonImg);

    // Inject styles into shadow DOM
    const styles = document.createElement('style');
    styles.textContent = `
        .lemonade-btn {
            all: initial;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            border: none;
            background: transparent;
            cursor: pointer;
            pointer-events: auto;
            transition: transform 0.2s ease;
            animation: lemonade-bounce 0.5s ease;
        }

        .lemonade-btn:hover .lemonade-img {
            filter:
                drop-shadow(0 0 1.2px #000)
                drop-shadow(0 0 1.2px #000)
                drop-shadow(0 0 8px rgba(255,217,61,0.9));
        }

        .lemonade-btn:active {
            transform: scale(0.95);
        }

        .lemonade-btn .lemonade-img {
            width: 48px;
            height: 48px;
            filter:
                drop-shadow(0 0 1.2px #000)
                drop-shadow(0 0 1.2px #000);
            transition: filter 0.2s ease;
        }

        @keyframes lemonade-bounce {
            0% { transform: scale(0); opacity: 0; }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); opacity: 1; }
        }

        .lemonade-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 4px;
            min-width: 200px;
            max-width: 300px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            overflow: hidden;
            pointer-events: auto;
            animation: lemonade-fadeIn 0.2s ease;
        }

        .lemonade-dropdown-header {
            padding: 12px;
            background: linear-gradient(135deg, #FFD93D 0%, #F7DC6F 100%);
            color: #333;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 12px;
            font-weight: 600;
        }

        .lemonade-dropdown-item {
            display: flex;
            align-items: center;
            padding: 10px 12px;
            cursor: pointer;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 13px;
            color: #333;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.15s ease;
        }

        .lemonade-dropdown-item:hover {
            background: #f8f9fa;
        }

        .lemonade-dropdown-item:last-child {
            border-bottom: none;
        }

        .lemonade-dropdown-icon {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            font-size: 14px;
        }

        .lemonade-dropdown-text {
            flex: 1;
            overflow: hidden;
        }

        .lemonade-dropdown-title {
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .lemonade-dropdown-subtitle {
            font-size: 11px;
            color: #666;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .lemonade-empty {
            padding: 20px;
            text-align: center;
            color: #666;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 13px;
        }

        .lemonade-loading {
            padding: 20px;
            text-align: center;
        }

        .lemonade-spinner {
            width: 24px;
            height: 24px;
            border: 2px solid #f0f0f0;
            border-top-color: #FFD93D;
            border-radius: 50%;
            animation: lemonade-spin 0.8s linear infinite;
        }

        @keyframes lemonade-spin {
            to { transform: rotate(360deg); }
        }

        @keyframes lemonade-fadeIn {
            from { opacity: 0; transform: translateY(-4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Fill animation when credential is selected */
        .lemonade-filling {
            position: relative;
            overflow: hidden;
            background: transparent !important;
        }

        .lemonade-filling::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: linear-gradient(90deg, #FFF4B8 0%, #FFD93D 50%, #FFF4B8 100%);
            background-size: 200% 100%;
            animation: lemonade-sweep 1s ease infinite;
            opacity: 0.4;
            z-index: 0;
            border-radius: 6px;
        }

        @keyframes lemonade-sweep {
            0% { background-position: 100% 0; }
            100% { background-position: -100% 0; }
        }

        .lemonade-fill-text {
            font-size: 12px;
            color: #B8860B;
            font-weight: 600;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            position: relative;
            z-index: 1;
        }

        .lemonade-fill-spinner {
            width: 20px;
            height: 20px;
            border: 2px solid #FFE88D;
            border-top-color: #D4A000;
            border-radius: 50%;
            animation: lemonade-spin 0.6s linear infinite;
            position: relative;
            z-index: 1;
        }

        /* Exit animations */
        .lemonade-exit {
            animation: lemonade-dropdown-exit 0.4s ease forwards;
        }

        @keyframes lemonade-dropdown-exit {
            0% { opacity: 1; transform: translateY(0) scale(1); }
            100% { opacity: 0; transform: translateY(-8px) scale(0.95); }
        }

        .lemonade-bye {
            animation: lemonade-fly-away 0.5s ease forwards;
        }

        @keyframes lemonade-fly-away {
            0% { transform: scale(1) rotate(0deg); opacity: 1; }
            50% { transform: scale(1.2) rotate(-10deg); opacity: 1; }
            100% { transform: scale(0) rotate(20deg) translateY(-30px); opacity: 0; }
        }
    `;

    shadow.appendChild(styles);
    shadow.appendChild(button);

    // Position the button
    positionLemonButton(shadowHost, passwordField);
    document.body.appendChild(shadowHost);

    // Store references
    const context = {
        shadowHost,
        shadow,
        button,
        passwordField,
        usernameField: findUsernameField(passwordField),
        dropdown: null
    };

    // Event handlers
    button.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleDropdown(context);
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (context.dropdown && !shadowHost.contains(e.target)) {
            closeDropdown(context);
        }
    });

    // Reposition on scroll/resize
    const repositionHandler = () => positionLemonButton(shadowHost, passwordField);
    window.addEventListener('scroll', repositionHandler, { passive: true });
    window.addEventListener('resize', repositionHandler, { passive: true });

    // Clean up if field is removed
    const observer = new MutationObserver(() => {
        if (!document.body.contains(passwordField)) {
            shadowHost.remove();
            observer.disconnect();
            window.removeEventListener('scroll', repositionHandler);
            window.removeEventListener('resize', repositionHandler);
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

/**
 * Position the lemon button relative to the password field
 */
function positionLemonButton(shadowHost, field) {
    const rect = field.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;

    shadowHost.style.left = `${rect.right + scrollX - 52}px`;
    shadowHost.style.top = `${rect.top + scrollY + (rect.height - 48) / 2}px`;
}

/**
 * Toggle the credentials dropdown
 */
function toggleDropdown(context) {
    if (context.dropdown) {
        closeDropdown(context);
    } else {
        openDropdown(context);
    }
}

/**
 * Open the credentials dropdown
 */
async function openDropdown(context) {
    const dropdown = document.createElement('div');
    dropdown.className = 'lemonade-dropdown';

    // Show loading state
    dropdown.innerHTML = `
        <div class="lemonade-dropdown-header">Lemonade Pass</div>
        <div class="lemonade-loading">
            <div class="lemonade-spinner"></div>
        </div>
    `;

    context.shadow.appendChild(dropdown);
    context.dropdown = dropdown;

    // Request credentials from background
    try {
        const domain = window.location.hostname;
        const response = await browser.runtime.sendMessage({
            type: 'GET_CREDENTIALS',
            domain: domain
        });

        if (response && response.success && response.credentials.length > 0) {
            renderCredentials(context, response.credentials);
        } else if (response && response.needsLogin) {
            renderLoginPrompt(context);
        } else {
            renderEmpty(context, domain);
        }
    } catch (error) {
        renderError(context);
    }
}

/**
 * Close the credentials dropdown
 */
function closeDropdown(context) {
    if (context.dropdown) {
        context.dropdown.remove();
        context.dropdown = null;
    }
}

/**
 * Render credentials in the dropdown
 */
function renderCredentials(context, credentials) {
    const dropdown = context.dropdown;
    if (!dropdown) return;

    const itemsHtml = credentials.map((cred, index) => `
        <div class="lemonade-dropdown-item" data-index="${index}">
            <div class="lemonade-dropdown-icon">${getIconForUrl(cred.url)}</div>
            <div class="lemonade-dropdown-text">
                <div class="lemonade-dropdown-title">${escapeHtml(cred.title)}</div>
                <div class="lemonade-dropdown-subtitle">${escapeHtml(cred.username)}</div>
            </div>
        </div>
    `).join('');

    dropdown.innerHTML = `
        <div class="lemonade-dropdown-header">Select credential</div>
        ${itemsHtml}
    `;

    // Add click handlers
    dropdown.querySelectorAll('.lemonade-dropdown-item').forEach(item => {
        item.addEventListener('click', async () => {
            const index = parseInt(item.dataset.index);
            const cred = credentials[index];

            // Transform item into loading state
            item.classList.add('lemonade-filling');
            const textEl = item.querySelector('.lemonade-dropdown-text');
            const iconEl = item.querySelector('.lemonade-dropdown-icon');
            if (textEl) textEl.innerHTML = '<div class="lemonade-fill-text">Filling...</div>';
            if (iconEl) iconEl.innerHTML = '<div class="lemonade-fill-spinner"></div>';

            // Disable other items
            dropdown.querySelectorAll('.lemonade-dropdown-item').forEach(i => {
                if (i !== item) i.style.opacity = '0.3';
                i.style.pointerEvents = 'none';
            });

            await fillCredentials(context, cred);

            // Animate out: dropdown fades, lemon flies away
            dropdown.classList.add('lemonade-exit');
            context.button.classList.add('lemonade-bye');
            setTimeout(() => {
                closeDropdown(context);
                context.shadowHost.remove();
            }, 500);
        });
    });
}

/**
 * Render login prompt
 */
function renderLoginPrompt(context) {
    const dropdown = context.dropdown;
    if (!dropdown) return;

    dropdown.innerHTML = `
        <div class="lemonade-dropdown-header">Lemonade Pass</div>
        <div class="lemonade-empty">
            <p>Please log in to use Lemonade</p>
            <p style="font-size: 11px; margin-top: 8px;">Click the extension icon to log in</p>
        </div>
    `;
}

/**
 * Render empty state
 */
function renderEmpty(context, domain) {
    const dropdown = context.dropdown;
    if (!dropdown) return;

    dropdown.innerHTML = `
        <div class="lemonade-dropdown-header">Lemonade Pass</div>
        <div class="lemonade-empty">
            <p>No credentials for ${escapeHtml(domain)}</p>
            <p style="font-size: 11px; margin-top: 8px;">Add credentials in the Lemonade app</p>
        </div>
    `;
}

/**
 * Render error state
 */
function renderError(context) {
    const dropdown = context.dropdown;
    if (!dropdown) return;

    dropdown.innerHTML = `
        <div class="lemonade-dropdown-header">Lemonade Pass</div>
        <div class="lemonade-empty">
            <p>Error loading credentials</p>
            <p style="font-size: 11px; margin-top: 8px;">Please try again</p>
        </div>
    `;
}

/**
 * Fill credentials into the form
 */
async function fillCredentials(context, credential) {
    // Get decrypted password from background
    const response = await browser.runtime.sendMessage({
        type: 'GET_DECRYPTED_PASSWORD',
        entryId: credential.id
    });

    if (!response || !response.success) {
        return;
    }

    const password = response.password;
    const username = credential.username;

    // Fill username if field exists
    if (context.usernameField && username) {
        fillField(context.usernameField, username);
    }

    // Fill password
    if (context.passwordField && password) {
        fillField(context.passwordField, password);
    }

}

/**
 * Fill a field and trigger appropriate events
 */
function fillField(field, value) {
    // Focus the field
    field.focus();

    // Set the value
    field.value = value;

    // Trigger events to notify frameworks (React, Angular, Vue, etc.)
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
    field.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
    field.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

    // Blur to trigger validation
    field.blur();
}

/**
 * Observe DOM changes to detect dynamically added forms
 */
function observeDOMChanges() {
    const observer = new MutationObserver((mutations) => {
        let shouldScan = false;

        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        if (node.querySelector &&
                            (node.querySelector('input[type="password"]') ||
                             node.matches && node.matches('input[type="password"]'))) {
                            shouldScan = true;
                            break;
                        }
                    }
                }
            }
            if (shouldScan) break;
        }

        if (shouldScan) {
            // Debounce scanning
            clearTimeout(window.lemonadeScanTimeout);
            window.lemonadeScanTimeout = setTimeout(scanForLoginForms, 100);
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

/**
 * Get an icon emoji for a URL
 */
function getIconForUrl(url) {
    if (!url) return '🔑';

    const domain = url.toLowerCase();

    if (domain.includes('google')) return '🔵';
    if (domain.includes('github')) return '🐙';
    if (domain.includes('facebook') || domain.includes('meta')) return '📘';
    if (domain.includes('twitter') || domain.includes('x.com')) return '🐦';
    if (domain.includes('amazon')) return '📦';
    if (domain.includes('apple')) return '🍎';
    if (domain.includes('microsoft')) return '🪟';
    if (domain.includes('netflix')) return '🎬';
    if (domain.includes('spotify')) return '🎵';
    if (domain.includes('linkedin')) return '💼';

    return '🔑';
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Listen for autofill messages from popup
 */
browser.runtime.onMessage.addListener((message, sender) => {
    if (message.type === 'AUTOFILL') {
        const passwordFields = findPasswordFields();

        if (passwordFields.length > 0) {
            const passwordField = passwordFields[0];
            const usernameField = findUsernameField(passwordField);

            // Fill username
            if (usernameField && message.username) {
                fillField(usernameField, message.username);
            }

            // Fill password
            if (passwordField && message.password) {
                fillField(passwordField, message.password);
            }

            return Promise.resolve({ success: true });
        } else {
            return Promise.resolve({ success: false, error: 'No password field found' });
        }
    }

    return false;
});
